package com.example.dbproject.historyApp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.dbproject.homeApp.NOTICE;

import java.util.ArrayList;

public class HistoryDBHelper extends SQLiteOpenHelper {

    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "inquire500.db";

    public HistoryDBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 데이터 베이스가 생성이 될 때 호출
        db.execSQL("CREATE TABLE IF NOT EXISTS STUDENT (id INTEGER PRIMARY KEY AUTOINCREMENT, pw TEXT, name TEXT, dp1 TEXT, dp2 TEXT, sDate TEXT, status TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS ITEM (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, category TEXT, location TEXT, type TEXT, status TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS RENTAL (id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER, item_id INTEGER, start_date TEXT, expired_date TEXT, return_date TEXT, extend TEXT, return TEXT, FOREIGN KEY (student_id) REFERENCES STUDENT(id) ON UPDATE CASCADE ON DELETE NO ACTION, FOREIGN KEY (item_id) REFERENCES ITEM(id) ON UPDATE CASCADE ON DELETE NO ACTION)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    // SELECT 문
    public ArrayList<HISTORY> getHistoryList(Integer student_id) {
        ArrayList<HISTORY> historyItems = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String[] selectionArgs = {String.valueOf(student_id)};
        Cursor cursor = db.rawQuery("SELECT RENTAL.*, ITEM.name AS item_name " +
                "FROM RENTAL " +
                "JOIN STUDENT ON RENTAL.student_d = STUDENT.id " +
                "JOIN ITEM ON RENTAL.item_id = ITEM.id " +
                "WHERE STUDENT.id = ? " +
                "AND (STUDENT.dp1 = ITEM.location OR STUDENT.dp2 = ITEM.location);", selectionArgs);
        if(cursor.getCount() != 0) {
            // 조회된 데이터가 있을 때 내부 수행
            int history_id_Index = cursor.getColumnIndex("id");
            int history_item_id_Index = cursor.getColumnIndex("item_id");
            int history_item_name_Index = cursor.getColumnIndex("item_name");
            int history_start_date_Index = cursor.getColumnIndex("start_date");
            int history_return_date_Index = cursor.getColumnIndex("return_date");
            int history_return_state_Index = cursor.getColumnIndex("return");

            while (cursor.moveToNext()) {
                Integer history_id = cursor.getInt(history_id_Index);
                Integer item_id = cursor.getInt(history_item_id_Index);
                String history_item_name = cursor.getString(history_item_name_Index);
                String history_start_date = cursor.getString(history_start_date_Index);
                String history_return_date = cursor.getString(history_return_date_Index);
                String history_return_state = cursor.getString(history_return_state_Index);

                HISTORY history = new HISTORY();
                history.setHistory_id(history_id);
                history.setHistory_item_id(item_id);
                history.setHistory_item_name(history_item_name);
                history.setHistory_start_date(history_start_date);
                history.setHistory_return_date(history_return_date);
                history.setHistory_return_state(history_return_state);
                historyItems.add(history);
            }
        }
        cursor.close();

        return historyItems;
    }


    // INSERT 문
    public void InsertStudent(Integer _id, String _pw, String _name, String _dp1, String _dp2, String _sDate, String _status) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO NOTICE (id, pw, name, dp1, dp2, sDate, status) VALUES('" + _id + "','" + _pw + "','" + _name + "','" + _dp1 + "','" + _dp2 + "','" + _sDate + "','" + _status + "');");
    }
    public void InsertItem(Integer _id, String _name, String _category, String _location, String _type, String _status) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO NOTICE (id, name, category, location, type, status) VALUES('" + _id + "','" + _name + "','" + _category + "','" + _location + "','" + _type + "','" + _status + "');");
    }
    public void InsertRental(Integer _id, Integer _student_id, Integer _item_id, String _start_date, String _expired_date, String _return_date, String _extend, String _return) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO NOTICE (id, student_id, item_id, start_date, expired_date, return_date, extend, return) VALUES('" + _id + "','" + _student_id + "','" + _item_id + "','" + _start_date + "','" + _expired_date + "','" + _return_date + "','" + _extend + "','" + _return + "');");
    }

    // UPDATE 문
//    public void UpdateNotice(String _title, String _content, String _writer, String _date, String _beforeData) {
//        SQLiteDatabase db = getWritableDatabase();
//        db.execSQL("UPDATE NOTICE SET title='" + _title + "', content='" + _content + "', writer='" + _writer + "', date='" + _date + "', WHERE date='" + _beforeData + "'");
//    }

    // DELETE 문
//    public void DeleteNotice(int _id) {
//        SQLiteDatabase db = getWritableDatabase();
//        db.execSQL("DELETE FROM NOTICE WHERE id = '" + _id + "'");
//    }

}
