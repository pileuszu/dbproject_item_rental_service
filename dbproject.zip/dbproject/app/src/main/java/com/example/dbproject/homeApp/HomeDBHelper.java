package com.example.dbproject.homeApp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class HomeDBHelper extends SQLiteOpenHelper {

    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "inquire.db";

    public HomeDBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 데이터 베이스가 생성이 될 때 호출
        db.execSQL("CREATE TABLE IF NOT EXISTS NOTICE (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, content TEXT, writer TEXT, date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    // SELECT 문
    public ArrayList<NOTICE> getNoticeList() {
        ArrayList<NOTICE> noticeItems = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM NOTICE", null);
        if(cursor.getCount() != 0) {
            // 조회된 데이터가 있을 때 내부 수행
            int titleIndex = cursor.getColumnIndex("title");
            int contentIndex = cursor.getColumnIndex("content");
            int writerIndex = cursor.getColumnIndex("writer");
            int dateIndex = cursor.getColumnIndex("date");

            while (cursor.moveToNext()) {
                String title = cursor.getString(titleIndex);
                String content = cursor.getString(contentIndex);
                String writer = cursor.getString(writerIndex);
                String date = cursor.getString(dateIndex);

                NOTICE notice = new NOTICE();
                notice.setTitle(title);
                notice.setContent(content);
                notice.setWriter(writer);
                notice.setDate(date);
                noticeItems.add(notice);
            }
        }
        cursor.close();

        return noticeItems;
    }


    // INSERT 문
    public void InsertNotice(String _title, String _content, String _writer, String _date) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO NOTICE (title, content, writer, date) VALUES('" + _title + "','" + _content + "','" + _writer + "','" + _date + "');");
    }

    // UPDATE 문
    public void UpdateNotice(String _title, String _content, String _writer, String _date, String _beforeData) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("UPDATE NOTICE SET title='" + _title + "', content='" + _content + "', writer='" + _writer + "', date='" + _date + "', WHERE date='" + _beforeData + "'");
    }

    // DELETE 문
    public void DeleteNotice(int _id) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM NOTICE WHERE id = '" + _id + "'");
    }

}
