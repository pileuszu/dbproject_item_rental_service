package com.example.dbproject.historyApp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.dbproject.R;
import com.example.dbproject.homeApp.HomeDBHelper;
import com.example.dbproject.homeApp.NOTICE;
import com.example.dbproject.homeApp.NoticeAdapter;

import java.util.ArrayList;

public class Fragment_History extends Fragment {
    public static final String TITLE = "title";
    public Integer studentID = 190012345;
    private RecyclerView mRv_history;
    private ArrayList<HISTORY> mHistoryItems;
    private HistoryDBHelper mHistoryDBHelper;
    private HistoryAdapter historyAdapter;
    public Fragment_History() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        setInit(view, studentID);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }


    private void setInit(View view, Integer _studentID) {
        mHistoryDBHelper = new HistoryDBHelper(getActivity().getApplicationContext());
        mRv_history = view.findViewById(R.id.recyclerView_history);
        mHistoryItems = new ArrayList<>();

        loadRecentDB(_studentID);
    }

    private void loadRecentDB(Integer _studentID) {
        mHistoryItems = mHistoryDBHelper.getHistoryList(_studentID);
        if(historyAdapter == null) {
            historyAdapter = new HistoryAdapter(mHistoryItems, getActivity().getApplicationContext());
            mRv_history.setHasFixedSize(true);
            mRv_history.setAdapter(historyAdapter);
        }


    }

}
